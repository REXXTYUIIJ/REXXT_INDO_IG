Bot Has Been Modified by IntecHost.in or @REXXT_888
FIST UPDATE ALL DETAILS IN
intechost.php
LIKE TOKEN ID ETC
=======================
Add Account
For Fresh IG
/addig USERNAME
-----------
For Indo IG
/addindo USERNAME
-----------
For IG+PP
/addpp USERNAME
=======================
Update Price
For Fresh IG
/priceig 10
-----------
For Indo IG
/price indo 10
-----------
For IG+PP
/pricepp
=======================
Update Password
For Fresh IG
/pass_fresh xxxx
-----------
For Indo IG
/pass_indo xxxx
-----------
For IG+PP
/pass_igcc xxxx
=======================
For BroadCasting
https://YOUR_DOMAIN/broadcast
-----------
For Check Users List
https://YOUR_DOMAIN/users.php